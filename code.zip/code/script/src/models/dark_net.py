from collections import defaultdict
import torch
import torch.nn as nn
import numpy as np


def create_modules(module_defs):
    hyperparams = module_defs.pop(0)
    output_filters = [int(hyperparams["channels"])]
    module_list = nn.ModuleList()
    for i, module_def in enumerate(module_defs):
        modules = nn.Sequential()
        if module_def["type"] == "convolutional":
            bn = int(module_def["batch_normalize"])
            filters = int(module_def["filters"])
            kernel_size = int(module_def["size"])
            pad = (kernel_size - 1) // 2 if int(module_def["pad"]) else 0
            modules.add_module(
                "conv_%d" % i,
                nn.Conv2d(
                    in_channels=output_filters[-1],
                    out_channels=filters,
                    kernel_size=kernel_size,
                    stride=int(module_def["stride"]),
                    dilation=1,
                    padding=pad,
                    bias=not bn,
                ),
            )
            if bn:
                modules.add_module("batch_norm_%d" % i, nn.BatchNorm2d(filters))
            if module_def["activation"] == "leaky":
                modules.add_module("leaky_%d" % i, nn.LeakyReLU())
        elif module_def["type"] == "upsample":
            upsample = nn.Upsample(scale_factor=int(module_def["stride"]))
            modules.add_module("upsample_%d" % i, upsample)
        elif module_def["type"] == "route":
            layers = [int(x) for x in module_def["layers"].split(",")]
            filters = sum([output_filters[layer_i] for layer_i in layers])
            modules.add_module("route_%d" % i, EmptyLayer())
        elif module_def["type"] == "shortcut":
            filters = output_filters[int(module_def["from"])]
            modules.add_module("shortcut_%d" % i, EmptyLayer())
        elif module_def["type"] == "yolo":
            anchor_idxs = [int(x) for x in module_def["mask"].split(",")]
            anchors = [float(x) for x in module_def["anchors"].split(",")]
            anchors = [(anchors[i], anchors[i + 1]) for i in range(0, len(anchors), 2)]
            anchors = [anchors[i] for i in anchor_idxs]
            num_classes = int(module_def["classes"])
            img_height = int(hyperparams["height"])
            yolo_layer = YOLOLayer(anchors, num_classes, img_height, anchor_idxs)
            modules.add_module("yolo_%d" % i, yolo_layer)
        module_list.append(modules)
        output_filters.append(filters)
    return hyperparams, module_list


class EmptyLayer(nn.Module):
    def __init__(self):
        super(EmptyLayer, self).__init__()


class YOLOLayer(nn.Module):
    def __init__(self, anchors, nC, img_dim, anchor_idxs):
        super(YOLOLayer, self).__init__()
        anchors = [(a_w, a_h) for a_w, a_h in anchors]
        nA = len(anchors)
        self.anchors = anchors
        self.nA = nA
        self.nC = nC
        self.bbox_attrs = 5 + nC
        self.img_dim = img_dim
        if anchor_idxs[0] == (nA * 2):
            stride = 32
        elif anchor_idxs[0] == nA:
            stride = 16
        else:
            stride = 8
        nG = int(self.img_dim / stride)
        self.grid_x = torch.arange(nG).repeat(nG, 1).view([1, 1, nG, nG]).float()
        self.grid_y = torch.arange(nG).repeat(nG, 1).t().view([1, 1, nG, nG]).float()
        self.scaled_anchors = torch.FloatTensor(
            [(a_w / stride, a_h / stride) for a_w, a_h in anchors]
        )
        self.anchor_w = self.scaled_anchors[:, 0:1].view((1, nA, 1, 1))
        self.anchor_h = self.scaled_anchors[:, 1:2].view((1, nA, 1, 1))

    def forward(self, p, targets=None, requestPrecision=False, weight=None, epoch=None):
        FT = torch.cuda.FloatTensor if p.is_cuda else torch.FloatTensor
        device = torch.device("cuda:4" if p.is_cuda else "cpu")
        bs = p.shape[0]
        nG = p.shape[2]
        stride = self.img_dim / nG
        if p.is_cuda and not self.grid_x.is_cuda:
            self.grid_x, self.grid_y = self.grid_x.cuda(), self.grid_y.cuda()
            self.anchor_w, self.anchor_h = self.anchor_w.cuda(), self.anchor_h.cuda()
        p = (
            p.view(bs, self.nA, self.bbox_attrs, nG, nG)
            .permute(0, 1, 3, 4, 2)
            .contiguous()
        )
        x = torch.sigmoid(p[..., 0])
        y = torch.sigmoid(p[..., 1])
        w = torch.sigmoid(p[..., 2])
        h = torch.sigmoid(p[..., 3])
        width = ((w.data * 2) ** 2) * self.anchor_w
        height = ((h.data * 2) ** 2) * self.anchor_h
        pred_boxes = FT(p[..., :4].shape)
        pred_conf = p[..., 4]
        pred_cls = p[..., 5:]
        if targets is not None:
            BCEWithLogitsLoss1 = nn.BCEWithLogitsLoss(size_average=False)
            BCEWithLogitsLoss0 = nn.BCEWithLogitsLoss()
            MSELoss = nn.MSELoss(size_average=False)
            CrossEntropyLoss = nn.CrossEntropyLoss(weight=weight)
            if requestPrecision:
                gx = self.grid_x[:, :, :nG, :nG]
                gy = self.grid_y[:, :, :nG, :nG]
                pred_boxes[..., 0] = x.data + gx - width / 2
                pred_boxes[..., 1] = y.data + gy - height / 2
                pred_boxes[..., 2] = x.data + gx + width / 2
                pred_boxes[..., 3] = y.data + gy + height / 2
            tx, ty, tw, th, mask, tcls, TP, FP, FN, TC = build_targets(
                pred_boxes,
                pred_conf,
                pred_cls,
                targets,
                self.scaled_anchors,
                self.nA,
                self.nC,
                nG,
                requestPrecision,
            )
            tcls = tcls[mask.bool()]
            if x.is_cuda:
                tx, ty, tw, th, mask, tcls = (
                    tx.cuda(),
                    ty.cuda(),
                    tw.cuda(),
                    th.cuda(),
                    mask.cuda(),
                    tcls.cuda(),
                )
            nM = mask.sum().float()
            nGT = sum([len(x) for x in targets])
            if nM > 0:
                lx = 2 * MSELoss(x[mask.bool()], tx[mask.bool()])
                ly = 2 * MSELoss(y[mask.bool()], ty[mask.bool()])
                lw = 4 * MSELoss(w[mask.bool()], tw[mask.bool()])
                lh = 4 * MSELoss(h[mask.bool()], th[mask.bool()])
                lconf = 1.5 * BCEWithLogitsLoss1(
                    pred_conf[mask.bool()], mask[mask.bool()].float()
                )
                lcls = nM * CrossEntropyLoss(
                    pred_cls[mask.bool()], torch.argmax(tcls, 1)
                )
            else:
                lx, ly, lw, lh, lcls, lconf = (
                    FT([0]),
                    FT([0]),
                    FT([0]),
                    FT([0]),
                    FT([0]),
                    FT([0]),
                )
            lconf += nM * BCEWithLogitsLoss0(
                pred_conf[~mask.bool()], mask[~mask.bool()].float()
            )
            loss = lx + ly + lw + lh + lconf + lcls
            i = torch.sigmoid(pred_conf[~mask.bool()]) > 0.999
            FPe = torch.zeros(60)
            if i.sum() > 0:
                FP_classes = torch.argmax(pred_cls[~mask.bool()][i], 1)
                for c in FP_classes:
                    FPe[c] += 1
            return (
                loss,
                loss.item(),
                lx.item(),
                ly.item(),
                lw.item(),
                lh.item(),
                lconf.item(),
                lcls.item(),
                nGT,
                TP,
                FP,
                FPe,
                FN,
                TC,
            )
        else:
            pred_boxes[..., 0] = x.data + self.grid_x
            pred_boxes[..., 1] = y.data + self.grid_y
            pred_boxes[..., 2] = width
            pred_boxes[..., 3] = height
            output = torch.cat(
                (
                    pred_boxes.view(bs, -1, 4) * stride,
                    torch.sigmoid(pred_conf.view(bs, -1, 1)),
                    pred_cls.view(bs, -1, self.nC),
                ),
                -1,
            )
            return output.data


class Darknet(nn.Module):
    def __init__(self, config_path, img_size=416):
        super(Darknet, self).__init__()
        self.module_defs = parse_model_config(config_path)
        self.module_defs[0]["height"] = img_size
        self.hyperparams, self.module_list = create_modules(self.module_defs)
        self.img_size = img_size
        self.loss_names = [
            "loss",
            "x",
            "y",
            "w",
            "h",
            "conf",
            "cls",
            "nGT",
            "TP",
            "FP",
            "FPe",
            "FN",
            "TC",
        ]

    def forward(self, x, targets=None, requestPrecision=False, weight=None, epoch=None):
        is_training = targets is not None
        output = []
        self.losses = defaultdict(float)
        layer_outputs = []
        for i, (module_def, module) in enumerate(
            zip(self.module_defs, self.module_list)
        ):
            if module_def["type"] in ["convolutional", "upsample"]:
                x = module(x)
            elif module_def["type"] == "route":
                layer_i = [int(x) for x in module_def["layers"].split(",")]
                x = torch.cat([layer_outputs[i] for i in layer_i], 1)
            elif module_def["type"] == "shortcut":
                layer_i = int(module_def["from"])
                x = layer_outputs[-1] + layer_outputs[layer_i]
            elif module_def["type"] == "yolo":
                if is_training:
                    x, *losses = module[0](x, targets, requestPrecision, weight, epoch)
                    for name, loss in zip(self.loss_names, losses):
                        self.losses[name] += loss
                else:
                    x = module(x)
                output.append(x)
            layer_outputs.append(x)
        return layer_outputs[-1]


def parse_model_config(path):
    file = open(path, "r")
    lines = file.read().split("\n")
    lines = [x for x in lines if x and not x.startswith("#")]
    lines = [x.rstrip().lstrip() for x in lines]
    module_defs = []
    for line in lines:
        if line.startswith("["):
            module_defs.append({})
            module_defs[-1]["type"] = line[1:-1].rstrip()
            if module_defs[-1]["type"] == "convolutional":
                module_defs[-1]["batch_normalize"] = 0
        else:
            key, value = line.split("=")
            value = value.strip()
            module_defs[-1][key.rstrip()] = value.strip()
    return module_defs
